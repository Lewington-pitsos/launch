str = ""

a = [3, 4, 5, 6, 7, 8, 8, 8].each_slice(3)  do
  |i| str +=i.join
  str += " "
end
p str


p ["4", "6", "8"].scan(/8/)
