Apparently the arrow-style of select boxes is pretty much entirely browser-dependant and very hard to alter otherwise, so i will assume that select arrows I've been given in the pdf only look different because they are being used in a different browser.

The greyed out items also change colour when hovered over, I think this was specified, but it looks a bit odd so I changed it to a different colour to lend a little distinctiveness.

I don't have Helvetica font, and it seems to cost like $48 so I've been using Arial and trying to make everything look close enough with Arial (the specs said to use the Helvetica Arial stack...). I have no idea what my page would look like actually using Helvetica.

Neither of the buttons on the modal make it go away. My reasoning was that both of these would be sending some request to the server, which would probably mean a page-refresh, which would get rid of the modal anyway. Instead the only way to exit the modal is by clicking on some of the greyed out area, which seems intuitive to me at least.

I am assuming that we're supposed to make the modal look ok on thinner screens so I did that.

I am assuming that I'm supposed to make links out of all the things that would probably be links.
